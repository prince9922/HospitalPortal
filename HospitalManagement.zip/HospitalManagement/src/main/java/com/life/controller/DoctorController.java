package com.life.controller;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.life.doctor.DoctorProfile;
import com.life.repo.HospitalRepo;
@Service
public class DoctorController {
	@Autowired
	private HospitalRepo repo;
	@Autowired
	private EntityManager em;
	
	public DoctorProfile insertData(DoctorProfile data)
	{
		
		DoctorProfile result=this.repo.save(data);
		return result;
		
	}
	
	//getting All doctors details
	
	public List<DoctorProfile> getDoctor()
	{
		List<DoctorProfile> getData=new ArrayList<DoctorProfile>();
		getData=(List<DoctorProfile>) this.repo.findAll();
		for(DoctorProfile li:getData)
		{
			System.out.println("checking error");
			System.out.println(li);
		}
		return getData;
		
	}
	//getting doctors details by id
	
	public DoctorProfile findById(int id)
	{
		return em.findAll(DoctorProfile.class);
	}
	
	public HospitalRepo getRepo() {
		return repo;
	}

	public void setRepo(HospitalRepo repo) {
		this.repo = repo;
	}
}
