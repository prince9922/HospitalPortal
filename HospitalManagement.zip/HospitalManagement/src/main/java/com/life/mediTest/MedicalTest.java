package com.life.mediTest;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="MedicalTest")
public class MedicalTest {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	@Column(name="TestName")
	private String testName;
	
	@Column(name="TestPrice")
	private double testPrice;

	public MedicalTest(int id, String testName, double testPrice) {
		super();
		this.id = id;
		this.testName = testName;
		this.testPrice = testPrice;
	}

	public MedicalTest() {
		super();
		// TODO Auto-generated constructor stub
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTestName() {
		return testName;
	}

	public void setTestName(String testName) {
		this.testName = testName;
	}

	public double getTestPrice() {
		return testPrice;
	}

	public void setTestPrice(double testPrice) {
		this.testPrice = testPrice;
	}
	
	
	

}
