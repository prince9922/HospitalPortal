package com.life.repo;

import org.springframework.data.repository.CrudRepository;

import com.life.doctor.DoctorProfile;

public interface HospitalRepo extends CrudRepository<DoctorProfile, Integer>{

}
