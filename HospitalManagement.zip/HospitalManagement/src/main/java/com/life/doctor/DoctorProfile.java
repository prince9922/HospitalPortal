package com.life.doctor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="DoctorProfile")
public class DoctorProfile {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int doctorId;
	@Column(name="doctorName")
	private String doctorName;
	@Column(name="speciality")
	private String speciality;
	@Column(name="DoctorShift")
	private String timeSlot;
	@Column(name="Availibility")
	private boolean isAvailable;
	public DoctorProfile(int doctorId, String doctorName, String speciality, String timeSlot, boolean isAvailable) {
		super();
		this.doctorId = doctorId;
		this.doctorName = doctorName;
		this.speciality = speciality;
		this.timeSlot = timeSlot;
		this.isAvailable = isAvailable;
	}
	public DoctorProfile() {
		super();
		// TODO Auto-generated constructor stub
	}
	public int getDoctorId() {
		return doctorId;
	}
	public void setDoctorId(int doctorId) {
		this.doctorId = doctorId;
	}
	public String getDoctorName() {
		return doctorName;
	}
	public void setDoctorName(String doctorName) {
		this.doctorName = doctorName;
	}
	public String getSpeciality() {
		return speciality;
	}
	public void setSpeciality(String speciality) {
		this.speciality = speciality;
	}
	public String getTimeSlot() {
		return timeSlot;
	}
	public void setTimeSlot(String timeSlot) {
		this.timeSlot = timeSlot;
	}
	public boolean isAvailable() {
		return isAvailable;
	}
	public void setAvailable(boolean isAvailable) {
		this.isAvailable = isAvailable;
	}
	@Override
	public String toString() {
		return "DoctorProfile [doctorId=" + doctorId + ", doctorName=" + doctorName + ", speciality=" + speciality
				+ ", timeSlot=" + timeSlot + ", isAvailable=" + isAvailable + "]";
	}
	
	
	
	
	

}
